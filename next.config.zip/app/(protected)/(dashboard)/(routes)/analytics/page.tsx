const AnalyticsPage = () => {
    return ( 
        <div>
            Analytics
        </div>
     );
}
 
export default AnalyticsPage;