-- AlterTable
ALTER TABLE "File" ADD COLUMN     "dateTime" TIMESTAMP(3);

-- AlterTable
ALTER TABLE "Requirement" ADD COLUMN     "note" TEXT;
